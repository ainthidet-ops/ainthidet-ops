/** School Media shared database. Execute as deployer; restrict access to signed-in Google accounts. */
const DATABASE_ID_ = '1OS0Yx6H6kjtaLpCQXtgJIfudOi9lA-TuF331zWfj9Fc';
const TABLES_ = ['buildings','rooms','devices','tickets','surveys','history','moves'];
function doGet() { return HtmlService.createHtmlOutputFromFile('Index').setTitle('ระบบบริหารสื่อและเทคโนโลยีโรงเรียน').addMetaTag('viewport','width=device-width, initial-scale=1'); }
function book_() { return SpreadsheetApp.openById(DATABASE_ID_); }
function empty_() { const s={version:2,updatedAt:null}; TABLES_.forEach(k=>s[k]=[]); return s; }
function store_() {
 const b=book_(); let s=b.getSheetByName('_SchoolMediaJournal');
 if(!s) { s=b.insertSheet('_SchoolMediaJournal'); s.getRange('A1').setValue(JSON.stringify({revision:0,start:0,count:0,requests:[]})); s.getRange('A2:B2').setValues([['snapshot_id','base64_payload']]); }
 return s;
}
function read_(s) {
 const meta=JSON.parse(s.getRange('A1').getValue());
 if(!meta.revision) return {revision:0,state:seed_(),requests:[]};
 const encoded=s.getRange(meta.start,2,meta.count,1).getValues().map(r=>r[0]).join('');
 const json=Utilities.newBlob(Utilities.base64DecodeWebSafe(encoded)).getDataAsString('UTF-8');
 if(hash_(json)!==meta.hash) throw Error('ข้อมูลกลางไม่ผ่านการตรวจสอบ กรุณาติดต่อผู้ดูแล ห้ามเริ่มฐานข้อมูลใหม่');
 return {revision:meta.revision,state:JSON.parse(json),requests:meta.requests||[]};
}
function hash_(s) {return Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,s,Utilities.Charset.UTF_8));}
function locked_(fn) {const lock=LockService.getScriptLock();lock.waitLock(30000);try{return fn();}finally{lock.releaseLock();}}
function getState(knownRevision) {return locked_(()=>{const current=read_(store_());return current.revision===knownRevision?{revision:current.revision,unchanged:true}:{revision:current.revision,state:current.state};});}
function commitState(expectedRevision,requestId,state) {
 return locked_(()=>{
  if(typeof requestId!=='string'||!/^[a-zA-Z0-9-]{8,100}$/.test(requestId))throw Error('รหัสคำขอไม่ถูกต้อง');
  validate_(state);const s=store_(),current=read_(s);
  if(current.requests.includes(requestId))return {revision:current.revision,state:current.state,duplicate:true};
  if(current.revision!==expectedRevision)return {conflict:true,revision:current.revision,state:current.state};
  // No deletion endpoint: lost rows are always rejected, including accidental empty writes.
  TABLES_.forEach(k=>{const ids=new Set(state[k].map(x=>x.id));if(current.state[k].some(x=>!ids.has(x.id)))throw Error('ปฏิเสธการบันทึกที่ทำให้รายการเดิมสูญหาย');});
  state.updatedAt=new Date().toISOString();const json=JSON.stringify(state);
  if(json.length>4000000)throw Error('ฐานข้อมูลเกินขนาดที่รองรับ กรุณาติดต่อผู้ดูแล');
  const encoded=Utilities.base64EncodeWebSafe(json,Utilities.Charset.UTF_8),chunks=encoded.match(/.{1,30000}/g),start=Math.max(s.getLastRow()+1,3);
  if(start+chunks.length-1>s.getMaxRows())s.insertRowsAfter(s.getMaxRows(),start+chunks.length-1-s.getMaxRows());
  s.getRange(start,1,chunks.length,2).setValues(chunks.map(c=>[requestId,c]));SpreadsheetApp.flush();
  const check=s.getRange(start,2,chunks.length,1).getValues().map(r=>r[0]).join('');if(check!==encoded)throw Error('บันทึกไม่ครบ กรุณาลองอีกครั้ง');
  const revision=current.revision+1;
  s.getRange('A1').setValue(JSON.stringify({revision,start,count:chunks.length,hash:hash_(json),requests:[...current.requests,requestId].slice(-200)}));SpreadsheetApp.flush();
  return {revision,state};
 });
}
function validate_(s) {
 if(!s||s.version!==2)throw Error('รุ่นข้อมูลไม่ถูกต้อง');
 TABLES_.forEach(k=>{if(!Array.isArray(s[k])||s[k].length>30000)throw Error('รูปแบบตารางไม่ถูกต้อง: '+k);const ids=new Set();s[k].forEach(r=>{if(!r||typeof r.id!=='string'||!r.id||ids.has(r.id))throw Error('รหัสรายการซ้ำหรือไม่ถูกต้อง: '+k);ids.add(r.id);});});
 const buildings=new Set(s.buildings.map(x=>x.id)),rooms=new Set(s.rooms.map(x=>x.id)),devices=new Set(s.devices.map(x=>x.id)),tickets=new Set(s.tickets.map(x=>x.id));
 s.rooms.forEach(r=>{if(!buildings.has(r.buildingId))throw Error('ห้องไม่มีอาคารอ้างอิง');});
 [...s.devices,...s.tickets,...s.surveys].forEach(r=>{if(!rooms.has(r.roomId))throw Error('รายการไม่มีห้องอ้างอิง');});
 s.devices.forEach(r=>{if(!Number.isInteger(r.qty)||r.qty<0||r.qty>9999)throw Error('จำนวนอุปกรณ์ไม่ถูกต้อง');});
 s.history.forEach(r=>{if(!tickets.has(r.ticketId))throw Error('ประวัติไม่มีงานซ่อมอ้างอิง');});
 s.moves.forEach(r=>{if(!devices.has(r.deviceId)||!rooms.has(r.fromRoomId)||!rooms.has(r.toRoomId))throw Error('ประวัติย้ายอ้างอิงไม่ครบ');});
}
function seed_() {
 // Preserve existing workbook rows; never clear or rewrite the original tabs.
 const b=book_(),s=empty_();
 const specs=[['อาคาร','buildings',['id','name','category','owner']],['ห้อง','rooms',['id','buildingId','name','floor','type','owner']],['อุปกรณ์','devices',['id','roomId','category','name','qty','status','model','updatedAt']],['แจ้งซ่อม','tickets',['id','eventDate','fiscalYear','roomId','deviceId','category','name','reporter','problem','status','owner','closedAt']],['สำรวจใหม่','surveys',['id','eventDate','fiscalYear','roomId','deviceId','category','name','qty','status','surveyor','note']],['สำรวจย้อนหลัง','surveys',['id','eventDate','fiscalYear','roomId','deviceId','category','name','qty','status','surveyor','note']],['ประวัติซ่อม','history',['id','ticketId','eventDate','fiscalYear','oldStatus','status','owner','note']],['ประวัติย้าย','moves',['id','deviceId','fromRoomId','toRoomId','eventDate','fiscalYear','owner','note']]];
 specs.forEach(([name,key,fields])=>{const t=b.getSheetByName(name);if(!t||t.getLastRow()<2)return;t.getRange(2,1,t.getLastRow()-1,fields.length).getValues().filter(r=>r[0]).forEach(row=>{const item={};fields.forEach((f,i)=>item[f]=row[i] instanceof Date?Utilities.formatDate(row[i],'Asia/Bangkok','yyyy-MM-dd'):row[i]);if(s[key].some(x=>x.id===item.id))throw Error('พบรหัสซ้ำในชีตเดิม '+name+' กรุณาตรวจสอบก่อนเริ่มระบบ');if('qty'in item)item.qty=Number(item.qty);s[key].push(item);});});
 validate_(s);return s;
}
/** Verify the real snapshot write/read path without adding equipment or changing totals. */
function testConnection() {
 const current=getState(null),result=commitState(current.revision,'check-'+Utilities.getUuid(),current.state);
 if(result.conflict)throw Error('มีการบันทึกจากเครื่องอื่น กรุณาทดสอบอีกครั้ง');
 const check=getState(null);
 if(check.revision<result.revision)throw Error('อ่านข้อมูลที่บันทึกกลับไม่ได้');
 return {revision:check.revision,state:check.state,verifiedAt:new Date().toISOString()};
}
